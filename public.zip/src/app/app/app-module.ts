import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // <-- Import this
import { EmployeeListComponent } from '../Components/EmployeeList/employeelist.component';

@NgModule({
  declarations: [
    // ...existing code...
  ],
  imports: [
    BrowserModule,
    FormsModule,
    EmployeeListComponent
  ],
  providers: [],
})
export class AppModule { }
