import { Routes } from '@angular/router';
import { EmployeeListComponent } from './Components/EmployeeList/employeelist.component';
import { RazorpayComponent } from './Components/Payment/razorpay.component';

export const routes: Routes = [
  { path: '', redirectTo: 'employees', pathMatch: 'full' },
  { path: 'employees', component: EmployeeListComponent } // 👈 no module needed
  ,{ path: 'payment', component: RazorpayComponent }
];

