import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-razorpay',
  imports: [CommonModule],
  templateUrl: './razorpay.component.html'
})
export class RazorpayComponent {
  // NOTE: Replace this with your real Razorpay key ID in production and
  // create an order on the server to get a real order_id.
  readonly RAZORPAY_KEY = 'rzp_test_YOUR_KEY_HERE';

  payNow() {
    debugger;
    // dynamically load Razorpay script if not already loaded
    if (!document.getElementById('razorpay-script')) {
      const script = document.createElement('script');
      script.id = 'razorpay-script';
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => this.openCheckout();
      document.body.appendChild(script);
    } else {
      this.openCheckout();
    }
  }

  openCheckout() {
    const options: any = {
      key: this.RAZORPAY_KEY,
      amount: 50000, // amount in paise: 50000 = INR 500
      currency: 'INR',
      name: 'EmployeeDetails Demo',
      description: 'Test Transaction',
      // In production, create order on server and pass the order_id here
      // order_id: 'order_XXXX',
      handler: (response: any) => {
        debugger;
        alert('Payment successful! Payment id: ' + response.razorpay_payment_id);
      },
      prefill: {
        name: 'Test User',
        email: 'test@example.com',
        contact: '9999999999'
      },
      theme: {
        color: '#3399cc'
      }
    };

    // @ts-ignore (Razorpay is added to window by the script)
    const rzp = new (window as any).Razorpay(options);
    rzp.open();
  }
}
